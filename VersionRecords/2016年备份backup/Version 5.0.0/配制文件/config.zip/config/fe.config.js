/**
 * project [mogoroom-renterembed-fe] configuration
 */
define([], function () {
    return {
        system:"dist",
        apiPath:'https://renter-embed.api.mogoroom.com/mogoroom-renterembed'

    }
});
